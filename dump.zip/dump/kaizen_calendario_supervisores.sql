-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: kaizen
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'ba5d3104-fc7c-11f0-94f9-c4efbb91b416:1-144';

--
-- Table structure for table `calendario_supervisores`
--

DROP TABLE IF EXISTS `calendario_supervisores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendario_supervisores` (
  `Id_Calendario_Supervisor` int NOT NULL AUTO_INCREMENT,
  `Id_Calendario` int NOT NULL,
  `Id_Supervisor` int NOT NULL,
  `Id_Linea_Supervisor` int NOT NULL COMMENT 'Línea a la que pertenece el supervisor',
  `Activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`Id_Calendario_Supervisor`),
  KEY `idx_calendario` (`Id_Calendario`),
  KEY `idx_supervisor` (`Id_Supervisor`),
  KEY `idx_linea_supervisor` (`Id_Linea_Supervisor`),
  CONSTRAINT `calendario_supervisores_ibfk_1` FOREIGN KEY (`Id_Calendario`) REFERENCES `calendario` (`Id_Calendario`),
  CONSTRAINT `calendario_supervisores_ibfk_2` FOREIGN KEY (`Id_Supervisor`) REFERENCES `usuarios` (`Id_Usuario`),
  CONSTRAINT `calendario_supervisores_ibfk_3` FOREIGN KEY (`Id_Linea_Supervisor`) REFERENCES `linea` (`Id_Linea`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Asignación de supervisores a evaluaciones (bracket)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendario_supervisores`
--

LOCK TABLES `calendario_supervisores` WRITE;
/*!40000 ALTER TABLE `calendario_supervisores` DISABLE KEYS */;
INSERT INTO `calendario_supervisores` VALUES (1,1,3,1,1),(2,2,7,2,1),(3,3,11,3,1),(4,4,13,4,1),(5,5,16,5,1),(6,6,20,6,1),(7,7,22,7,1),(8,8,25,8,1),(9,9,27,9,1),(10,10,30,10,1),(11,11,32,11,1),(12,12,38,12,1);
/*!40000 ALTER TABLE `calendario_supervisores` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-12 16:04:49
