-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: kaizen
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'ba5d3104-fc7c-11f0-94f9-c4efbb91b416:1-144';

--
-- Table structure for table `calendario`
--

DROP TABLE IF EXISTS `calendario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendario` (
  `Id_Calendario` int NOT NULL AUTO_INCREMENT,
  `Mes` int NOT NULL COMMENT 'Mes (1-12)',
  `Anio` int NOT NULL COMMENT 'Año',
  `Semana_Mes` int NOT NULL COMMENT 'Semana del mes (1-5)',
  `Fecha_Inicio` date NOT NULL COMMENT 'Lunes de la semana',
  `Fecha_Fin` datetime NOT NULL COMMENT 'Miércoles 3pm límite',
  `Id_Linea_Evaluada` int NOT NULL,
  `Id_Auditoria` int NOT NULL DEFAULT '1' COMMENT 'Siempre 1 para evaluaciones',
  `Id_Estado` int DEFAULT '1' COMMENT '1=Sin Evaluacion, 2=En Revision, 3=Finalizado',
  `Fecha_Creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `Activo` tinyint(1) DEFAULT '1',
  `Hora_Inicio` time DEFAULT NULL,
  `Hora_Fin` time DEFAULT NULL,
  PRIMARY KEY (`Id_Calendario`),
  KEY `idx_mes_anio` (`Mes`,`Anio`),
  KEY `idx_fecha_inicio` (`Fecha_Inicio`),
  KEY `idx_linea_evaluada` (`Id_Linea_Evaluada`),
  KEY `idx_auditoria` (`Id_Auditoria`),
  KEY `idx_estado` (`Id_Estado`),
  CONSTRAINT `calendario_ibfk_1` FOREIGN KEY (`Id_Linea_Evaluada`) REFERENCES `linea` (`Id_Linea`),
  CONSTRAINT `calendario_ibfk_2` FOREIGN KEY (`Id_Auditoria`) REFERENCES `tipo_auditoria` (`Id_Auditoria`),
  CONSTRAINT `calendario_ibfk_3` FOREIGN KEY (`Id_Estado`) REFERENCES `tipo_estados` (`Id_Estado`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Calendario semanal de evaluaciones tipo bracket';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendario`
--

LOCK TABLES `calendario` WRITE;
/*!40000 ALTER TABLE `calendario` DISABLE KEYS */;
INSERT INTO `calendario` VALUES (1,2,2026,2,'2026-02-10','2026-02-12 15:00:00',2,1,3,'2026-02-12 11:07:33',1,'09:00:00','11:00:00'),(2,2,2026,2,'2026-02-10','2026-02-12 15:00:00',3,1,2,'2026-02-12 11:07:33',1,'11:30:00','13:00:00'),(3,2,2026,2,'2026-02-10','2026-02-12 15:00:00',4,1,3,'2026-02-12 11:07:33',1,'14:00:00','16:00:00'),(4,2,2026,2,'2026-02-10','2026-02-12 15:00:00',5,1,1,'2026-02-12 11:07:33',1,'16:30:00','18:00:00'),(5,2,2026,2,'2026-02-10','2026-02-12 15:00:00',6,1,3,'2026-02-12 11:07:33',1,'09:00:00','11:00:00'),(6,2,2026,2,'2026-02-10','2026-02-12 15:00:00',7,1,3,'2026-02-12 11:07:33',1,'13:00:00','15:00:00'),(7,2,2026,2,'2026-02-10','2026-02-12 15:00:00',8,1,2,'2026-02-12 11:07:33',1,'09:00:00','11:00:00'),(8,2,2026,2,'2026-02-10','2026-02-12 15:00:00',9,1,3,'2026-02-12 11:07:33',1,'13:00:00','15:00:00'),(9,2,2026,2,'2026-02-10','2026-02-12 15:00:00',10,1,3,'2026-02-12 11:07:33',1,'09:00:00','11:00:00'),(10,2,2026,2,'2026-02-10','2026-02-12 15:00:00',11,1,3,'2026-02-12 11:07:33',1,'13:00:00','15:00:00'),(11,2,2026,2,'2026-02-10','2026-02-12 15:00:00',12,1,3,'2026-02-12 11:07:33',1,'09:00:00','11:00:00'),(12,2,2026,2,'2026-02-10','2026-02-12 15:00:00',13,1,3,'2026-02-12 11:07:33',1,'13:00:00','15:00:00');
/*!40000 ALTER TABLE `calendario` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-12 16:04:47
