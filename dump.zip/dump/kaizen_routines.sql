-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: kaizen
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'ba5d3104-fc7c-11f0-94f9-c4efbb91b416:1-144';

--
-- Temporary view structure for view `v_retroalimentaciones_pendientes`
--

DROP TABLE IF EXISTS `v_retroalimentaciones_pendientes`;
/*!50001 DROP VIEW IF EXISTS `v_retroalimentaciones_pendientes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_retroalimentaciones_pendientes` AS SELECT 
 1 AS `Id_CheckList`,
 1 AS `Fecha_Evaluacion`,
 1 AS `Nombre_Linea`,
 1 AS `Pregunta`,
 1 AS `Cumple`,
 1 AS `Observacion`,
 1 AS `Evaluador`,
 1 AS `Estado`,
 1 AS `Estado_Retroalimentacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_dashboard_evaluaciones`
--

DROP TABLE IF EXISTS `v_dashboard_evaluaciones`;
/*!50001 DROP VIEW IF EXISTS `v_dashboard_evaluaciones`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_dashboard_evaluaciones` AS SELECT 
 1 AS `Id_Calendario`,
 1 AS `Mes`,
 1 AS `Anio`,
 1 AS `Semana_Mes`,
 1 AS `Fecha_Inicio`,
 1 AS `Fecha_Fin`,
 1 AS `Linea_Evaluada`,
 1 AS `Total_Supervisores`,
 1 AS `Total_Respuestas`,
 1 AS `Preguntas_Contestadas`,
 1 AS `Preguntas_Cumple`,
 1 AS `Preguntas_No_Cumple`,
 1 AS `Porcentaje_Cumplimiento`,
 1 AS `Estado_Evaluacion`,
 1 AS `Id_Estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_preguntas_mes_actual`
--

DROP TABLE IF EXISTS `v_preguntas_mes_actual`;
/*!50001 DROP VIEW IF EXISTS `v_preguntas_mes_actual`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_preguntas_mes_actual` AS SELECT 
 1 AS `Id_Calendario_Pregunta`,
 1 AS `Mes`,
 1 AS `Anio`,
 1 AS `Orden`,
 1 AS `Id_Pregunta`,
 1 AS `Pregunta`,
 1 AS `Descripcion`,
 1 AS `Id_5S`,
 1 AS `Nombre_5S`,
 1 AS `Descripcion_5S`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_mi_evaluacion_actual`
--

DROP TABLE IF EXISTS `v_mi_evaluacion_actual`;
/*!50001 DROP VIEW IF EXISTS `v_mi_evaluacion_actual`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_mi_evaluacion_actual` AS SELECT 
 1 AS `Id_Calendario`,
 1 AS `Mes`,
 1 AS `Anio`,
 1 AS `Semana_Mes`,
 1 AS `Fecha_Inicio`,
 1 AS `Fecha_Fin`,
 1 AS `Id_Linea_Evaluada`,
 1 AS `Linea_A_Evaluar`,
 1 AS `Unidad_Negocio`,
 1 AS `Nave`,
 1 AS `Id_Supervisor`,
 1 AS `Nombre_Supervisor`,
 1 AS `Id_Linea_Supervisor`,
 1 AS `Mi_Linea`,
 1 AS `Id_Estado`,
 1 AS `Estado_Evaluacion`,
 1 AS `Descripcion_Estado`,
 1 AS `Estado_Acceso`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_retroalimentaciones_pendientes`
--

/*!50001 DROP VIEW IF EXISTS `v_retroalimentaciones_pendientes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_retroalimentaciones_pendientes` AS select `ch`.`Id_CheckList` AS `Id_CheckList`,`ch`.`Fecha` AS `Fecha_Evaluacion`,`l`.`Nombre_Linea` AS `Nombre_Linea`,`p`.`Pregunta` AS `Pregunta`,`ch`.`Cumple` AS `Cumple`,`ch`.`Observacion` AS `Observacion`,`u`.`Nombre` AS `Evaluador`,`te`.`Estado` AS `Estado`,(case when (`cr`.`Id_Retroalimentacion` is null) then 'Sin Retroalimentación' else 'Con Retroalimentación' end) AS `Estado_Retroalimentacion` from (((((`checklist` `ch` join `linea` `l` on((`ch`.`Id_Linea_Evaluada` = `l`.`Id_Linea`))) join `preguntas` `p` on((`ch`.`Id_Pregunta` = `p`.`Id_Pregunta`))) join `usuarios` `u` on((`ch`.`Id_Evaluador` = `u`.`Id_Usuario`))) join `tipo_estados` `te` on((`ch`.`Id_Estado` = `te`.`Id_Estado`))) left join `checklist_retroalimentacion` `cr` on((`ch`.`Id_CheckList` = `cr`.`Id_CheckList`))) where ((`ch`.`Id_Estado` = 2) and (`ch`.`Activo` = 1) and (`ch`.`Cumple` = 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_dashboard_evaluaciones`
--

/*!50001 DROP VIEW IF EXISTS `v_dashboard_evaluaciones`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dashboard_evaluaciones` AS select `c`.`Id_Calendario` AS `Id_Calendario`,`c`.`Mes` AS `Mes`,`c`.`Anio` AS `Anio`,`c`.`Semana_Mes` AS `Semana_Mes`,`c`.`Fecha_Inicio` AS `Fecha_Inicio`,`c`.`Fecha_Fin` AS `Fecha_Fin`,`l`.`Nombre_Linea` AS `Linea_Evaluada`,count(distinct `cs`.`Id_Supervisor`) AS `Total_Supervisores`,count(distinct `ch`.`Id_CheckList`) AS `Total_Respuestas`,count(distinct `ch`.`Id_Pregunta`) AS `Preguntas_Contestadas`,sum((case when (`ch`.`Cumple` = 1) then 1 else 0 end)) AS `Preguntas_Cumple`,sum((case when (`ch`.`Cumple` = 0) then 1 else 0 end)) AS `Preguntas_No_Cumple`,round((avg((case when (`ch`.`Cumple` is not null) then `ch`.`Cumple` else NULL end)) * 100),2) AS `Porcentaje_Cumplimiento`,`te`.`Estado` AS `Estado_Evaluacion`,`c`.`Id_Estado` AS `Id_Estado` from ((((`calendario` `c` join `linea` `l` on((`c`.`Id_Linea_Evaluada` = `l`.`Id_Linea`))) join `tipo_estados` `te` on((`c`.`Id_Estado` = `te`.`Id_Estado`))) left join `calendario_supervisores` `cs` on((`c`.`Id_Calendario` = `cs`.`Id_Calendario`))) left join `checklist` `ch` on((`c`.`Id_Calendario` = `ch`.`Id_Calendario`))) where (`c`.`Activo` = 1) group by `c`.`Id_Calendario`,`c`.`Mes`,`c`.`Anio`,`c`.`Semana_Mes`,`c`.`Fecha_Inicio`,`c`.`Fecha_Fin`,`l`.`Nombre_Linea`,`te`.`Estado`,`c`.`Id_Estado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_preguntas_mes_actual`
--

/*!50001 DROP VIEW IF EXISTS `v_preguntas_mes_actual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_preguntas_mes_actual` AS select `cp`.`Id_Calendario_Pregunta` AS `Id_Calendario_Pregunta`,`cp`.`Mes` AS `Mes`,`cp`.`Anio` AS `Anio`,`cp`.`Orden` AS `Orden`,`p`.`Id_Pregunta` AS `Id_Pregunta`,`p`.`Pregunta` AS `Pregunta`,`p`.`Descripcion` AS `Descripcion`,`ts`.`Id_5S` AS `Id_5S`,`ts`.`Nombre_5S` AS `Nombre_5S`,`ts`.`Descripcion` AS `Descripcion_5S` from ((`calendario_preguntas` `cp` join `preguntas` `p` on((`cp`.`Id_Pregunta` = `p`.`Id_Pregunta`))) join `tipo_5s` `ts` on((`p`.`Id_5S` = `ts`.`Id_5S`))) where ((`cp`.`Activo` = 1) and (`p`.`Activo` = 1) and (`cp`.`Mes` = month(curdate())) and (`cp`.`Anio` = year(curdate()))) order by `cp`.`Orden` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_mi_evaluacion_actual`
--

/*!50001 DROP VIEW IF EXISTS `v_mi_evaluacion_actual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_mi_evaluacion_actual` AS select `c`.`Id_Calendario` AS `Id_Calendario`,`c`.`Mes` AS `Mes`,`c`.`Anio` AS `Anio`,`c`.`Semana_Mes` AS `Semana_Mes`,`c`.`Fecha_Inicio` AS `Fecha_Inicio`,`c`.`Fecha_Fin` AS `Fecha_Fin`,`l`.`Id_Linea` AS `Id_Linea_Evaluada`,`l`.`Nombre_Linea` AS `Linea_A_Evaluar`,`bu`.`Unidad_Negocio` AS `Unidad_Negocio`,`l`.`Nave` AS `Nave`,`cs`.`Id_Supervisor` AS `Id_Supervisor`,`u`.`Nombre` AS `Nombre_Supervisor`,`cs`.`Id_Linea_Supervisor` AS `Id_Linea_Supervisor`,`l2`.`Nombre_Linea` AS `Mi_Linea`,`c`.`Id_Estado` AS `Id_Estado`,`te`.`Estado` AS `Estado_Evaluacion`,`te`.`Descripcion` AS `Descripcion_Estado`,(case when (`c`.`Fecha_Fin` < now()) then 'Cerrado' when (`c`.`Fecha_Inicio` > now()) then 'Próximo' else 'Disponible' end) AS `Estado_Acceso` from ((((((`calendario` `c` join `calendario_supervisores` `cs` on((`c`.`Id_Calendario` = `cs`.`Id_Calendario`))) join `linea` `l` on((`c`.`Id_Linea_Evaluada` = `l`.`Id_Linea`))) left join `bu` on((`l`.`Id_BU` = `bu`.`Id_BU`))) join `usuarios` `u` on((`cs`.`Id_Supervisor` = `u`.`Id_Usuario`))) join `linea` `l2` on((`cs`.`Id_Linea_Supervisor` = `l2`.`Id_Linea`))) join `tipo_estados` `te` on((`c`.`Id_Estado` = `te`.`Id_Estado`))) where ((`c`.`Activo` = 1) and (`cs`.`Activo` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-12 16:04:49
